package com.example.johir.my_project;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main2Activity extends AppCompatActivity{


    TextView t1;
    String id,des,title;

    ImageView imageView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

       // t1=(TextView)findViewById(R.id.textView2);

        Bundle bundle = getIntent().getExtras();
        String venid = bundle.getString("VENUE_id");
        String ventb = bundle.getString("VENUE_tb");
        String venimg = bundle.getString("VENUE_img");

        imageView=(ImageView)findViewById(R.id.imageViewNewsImage2);
        t1=(TextView)findViewById(R.id.textView_des);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Toast.makeText(getApplication(), venid+"tb"+ventb, Toast.LENGTH_SHORT).show();
        data33(venid,ventb);

        Glide.with(getApplication())
                .load("http://192.168.0.105:82/images/"+venimg)
                .centerCrop()
                .placeholder(R.drawable.side_nav_bar)
                .crossFade()
               .into(imageView);

       // t1.setText(venName);
    }


    public void data33(final String venid , final String ventb ){

        String url = "http://192.168.0.105:82/data/r2.php";

        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {


                            t1.setText(response.toString());

                          } catch (Exception e) {
                            // Do something with the exception
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String> params = new HashMap<>();
                // the POST parameters:
                params.put("id", venid);
                params.put("tb", ventb);
                return params;
            }
        };
        Volley.newRequestQueue(this).add(postRequest);


    }


}
