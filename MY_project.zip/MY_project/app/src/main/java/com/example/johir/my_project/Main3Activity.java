package com.example.johir.my_project;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;

public class Main3Activity extends AppCompatActivity {


    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        textView=(TextView)findViewById(R.id.textView_contain_3);



        new Thread(new Task()).start();
    }

    class Task implements Runnable {

        public void run() {

            for (int i = 0; i <= 0; i++) {

                final int value = i;
                try {
                    Thread.sleep(6000);

                } catch (InterruptedException e) {

                    e.printStackTrace();
                }

                Intent intent = new Intent(Main3Activity.this, MainActivity.class);
                startActivity(intent);




            }

        }


    }



}